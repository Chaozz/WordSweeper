package client.controller;

public class CheckManagingStatusController {

}
