package client.controller;

import junit.framework.TestCase;

public class StartPraticeControllerTest extends TestCase {

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testProcess() {
		fail("Not yet implemented");
	}

}
